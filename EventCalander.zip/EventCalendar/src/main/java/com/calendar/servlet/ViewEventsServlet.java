package com.calendar.servlet;

import com.calendar.dao.EventDAO;
import com.calendar.model.Event;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class ViewEventsServlet extends HttpServlet {
    private EventDAO dao = new EventDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            List<Event> events = dao.getAllEvents();
            request.setAttribute("events", events);
            RequestDispatcher rd = request.getRequestDispatcher("/view_calendar.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to retrieve events");
        }
    }
}
