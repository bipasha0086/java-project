package com.calendar.servlet;

import com.calendar.dao.EventDAO;
import com.calendar.model.Event;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Date;

public class AddEventServlet extends HttpServlet {
    private EventDAO dao = new EventDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String dateStr = request.getParameter("event_date");

        try {
            Date date = Date.valueOf(dateStr); // expects yyyy-MM-dd
            Event event = new Event();
            event.setTitle(title);
            event.setDescription(description);
            event.setEventDate(date);

            dao.addEvent(event);
            response.sendRedirect(request.getContextPath() + "/ViewEventsServlet");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Unable to add event");
        }
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.sendRedirect(req.getContextPath() + "/add_event.jsp");
    }
}
