package com.calendar.dao;

import java.sql.*;
import java.util.*;
import com.calendar.model.Event;

public class EventDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/event_calendar_db?useSSL=false&serverTimezone=UTC";
    private String jdbcUsername = "root";
    private String jdbcPassword = "Bipasha0086@";

    private static final String INSERT_EVENT_SQL = "INSERT INTO events (title, description, event_date) VALUES (?, ?, ?)";
    private static final String SELECT_ALL_EVENTS = "SELECT * FROM events ORDER BY event_date ASC";

    protected Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
    }

    public void addEvent(Event event) throws SQLException {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_EVENT_SQL)) {
            ps.setString(1, event.getTitle());
            ps.setString(2, event.getDescription());
            ps.setDate(3, event.getEventDate());
            ps.executeUpdate();
        }
    }

    public List<Event> getAllEvents() throws SQLException {
        List<Event> events = new ArrayList<>();
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_ALL_EVENTS);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Event e = new Event();
                e.setId(rs.getInt("id"));
                e.setTitle(rs.getString("title"));
                e.setDescription(rs.getString("description"));
                e.setEventDate(rs.getDate("event_date"));
                events.add(e);
            }
        }
        return events;
    }
}
